import os
import json
import boto3
from dotenv import load_dotenv

# load variables from backend/.env
load_dotenv(dotenv_path=os.path.join(os.path.dirname(__file__), '..', '.env'))

ddb = boto3.resource('dynamodb')
table = ddb.Table(os.environ['DDB_TABLE'])

# Initialize the DynamoDB client once, outside the handler
ddb = boto3.resource('dynamodb')
table = ddb.Table(os.environ['DDB_TABLE'])

def lambda_handler(event, context):
    try:
        # Scan the entire table (for production apps consider using Query or pagination)
        response = table.scan()
        items = response.get('Items', [])

        return {
            'statusCode': 200,
            'headers': { 'Content-Type': 'application/json' },
            'body': json.dumps(items)
        }

    except Exception as e:
        print(f"Error scanning table: {e}")
        return {
            'statusCode': 500,
            'headers': { 'Content-Type': 'application/json' },
            'body': json.dumps({ 'error': 'Could not fetch tasks' })
        }
